import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'PostPilot AI — Content, on autopilot',
  description: 'Create better social media content with AI.'
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
