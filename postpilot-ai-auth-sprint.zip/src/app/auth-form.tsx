'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { WandSparkles, ArrowLeft } from 'lucide-react';

export default function AuthForm({ mode }: { mode: 'login' | 'register' }) {
  const router = useRouter();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const isRegister = mode === 'register';

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError('');
    try {
      const response = await fetch(`/api/auth/${isRegister ? 'register' : 'login'}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Authentication failed.');
      router.replace('/dashboard');
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  }

  return <main className="flex min-h-screen items-center justify-center px-5 py-12">
    <div className="w-full max-w-md">
      <Link href="/" className="muted mb-8 inline-flex items-center gap-2 text-sm"><ArrowLeft size={16}/> Back to PostPilot</Link>
      <div className="panel p-7 sm:p-9">
        <Link href="/" className="mb-8 flex items-center gap-2 text-xl font-bold"><span className="rounded-xl bg-violet-500 p-2"><WandSparkles size={20}/></span>PostPilot<span className="gradient-text">AI</span></Link>
        <h1 className="text-2xl font-bold">{isRegister ? 'Create your account' : 'Welcome back'}</h1>
        <p className="muted mt-2 text-sm">{isRegister ? 'Start creating content for your business.' : 'Sign in to open your content studio.'}</p>
        <form onSubmit={submit} className="mt-7 space-y-4">
          {isRegister && <div><label className="mb-2 block text-sm">Name (optional)</label><input value={name} onChange={e=>setName(e.target.value)} autoComplete="name" maxLength={80} className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 outline-none focus:border-violet-400" placeholder="Your name"/></div>}
          <div><label className="mb-2 block text-sm">Email address</label><input type="email" required value={email} onChange={e=>setEmail(e.target.value)} autoComplete="email" maxLength={254} className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 outline-none focus:border-violet-400" placeholder="you@example.com"/></div>
          <div><label className="mb-2 block text-sm">Password</label><input type="password" required value={password} onChange={e=>setPassword(e.target.value)} autoComplete={isRegister ? 'new-password' : 'current-password'} minLength={isRegister ? 12 : 1} maxLength={128} className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 outline-none focus:border-violet-400" placeholder={isRegister ? 'At least 12 characters' : 'Your password'}/>{isRegister && <p className="muted mt-1 text-xs">Use at least 12 characters.</p>}</div>
          {error && <p role="alert" className="rounded-lg border border-rose-400/20 bg-rose-400/10 p-3 text-sm text-rose-200">{error}</p>}
          <button disabled={loading} className="w-full rounded-xl bg-violet-500 px-5 py-3 font-semibold hover:bg-violet-400 disabled:opacity-50">{loading ? 'Please wait...' : isRegister ? 'Create account' : 'Sign in'}</button>
        </form>
        <p className="muted mt-6 text-center text-sm">{isRegister ? 'Already have an account?' : 'New to PostPilot?'} <Link className="font-semibold text-violet-300 hover:text-violet-200" href={isRegister ? '/login' : '/signup'}>{isRegister ? 'Sign in' : 'Create an account'}</Link></p>
      </div>
      <p className="muted mt-5 text-center text-xs">Keep your password private. PostPilot will never ask you to share it with support.</p>
    </div>
  </main>;
}
