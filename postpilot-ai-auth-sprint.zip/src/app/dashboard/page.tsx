'use client';

import { useState } from 'react';
import Link from 'next/link';
import { WandSparkles, LayoutDashboard, CalendarDays, Settings, Sparkles, Copy, Check, ArrowLeft, LogOut } from 'lucide-react';

type Result = { caption: string; hashtags: string[]; ideas: string[] };

export default function Dashboard() {
  const [business, setBusiness] = useState('');
  const [topic, setTopic] = useState('');
  const [platform, setPlatform] = useState('Instagram');
  const [tone, setTone] = useState('Friendly');
  const [result, setResult] = useState<Result | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  async function generate() {
    setLoading(true); setError(''); setResult(null);
    try {
      const response = await fetch('/api/generate', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ business, topic, platform, tone })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Could not generate content.');
      setResult(data);
    } catch (e) { setError(e instanceof Error ? e.message : 'Something went wrong.'); }
    finally { setLoading(false); }
  }

  async function copyContent() {
    if (!result) return;
    await navigator.clipboard.writeText(`${result.caption}\n\n${result.hashtags.join(' ')}`);
    setCopied(true); setTimeout(() => setCopied(false), 1600);
  }

  return <div className="min-h-screen md:flex">
    <aside className="hidden w-64 shrink-0 border-r border-slate-800 bg-slate-950/70 p-6 md:block">
      <Link href="/" className="flex items-center gap-2 text-lg font-bold"><span className="rounded-lg bg-violet-500 p-2"><WandSparkles size={18}/></span>PostPilot AI</Link>
      <p className="muted mb-3 mt-10 text-xs uppercase tracking-widest">Workspace</p>
      <div className="flex items-center gap-3 rounded-xl bg-violet-500/15 px-4 py-3 text-sm text-violet-200"><LayoutDashboard size={17}/> Overview</div>
      <div className="muted mt-3 flex items-center gap-3 px-4 py-3 text-sm"><CalendarDays size={17}/> Content calendar</div>
      <div className="muted mt-3 flex items-center gap-3 px-4 py-3 text-sm"><Settings size={17}/> Settings</div>
      <div className="panel mt-12 p-4"><p className="text-sm font-semibold">Free workspace</p><p className="muted mt-1 text-xs">MVP preview. Plans and billing will be connected before launch.</p></div>
    </aside>
    <main className="mx-auto w-full max-w-6xl p-5 md:p-10">
      <Link href="/" className="muted mb-7 inline-flex items-center gap-2 text-sm md:hidden"><ArrowLeft size={16}/> Home</Link>
      <div className="flex flex-wrap items-center justify-between gap-4"><div><p className="muted text-sm">WORKSPACE / OVERVIEW</p><h1 className="mt-2 text-3xl font-bold">Good content starts here.</h1><p className="muted mt-2">Create a post tailored to your business and audience.</p></div><button onClick={async()=>{await fetch('/api/auth/logout',{method:'POST'}); window.location.href='/login';}} className="flex items-center gap-2 rounded-xl border border-slate-700 px-4 py-2 text-sm hover:border-slate-500"><LogOut size={15}/> Sign out</button></div>
      <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_1fr]">
        <section className="panel p-6">
          <div className="mb-6 flex items-center gap-3"><span className="rounded-xl bg-violet-500/15 p-3 text-violet-300"><Sparkles/></span><div><h2 className="font-bold">AI post generator</h2><p className="muted text-xs">Describe what you want to promote.</p></div></div>
          <label className="mb-2 block text-sm font-medium">Business name or type</label><input value={business} onChange={e=>setBusiness(e.target.value)} placeholder="e.g. Mumbi Fashion Store" className="mb-5 w-full rounded-xl border border-slate-700 bg-slate-950/70 px-4 py-3 outline-none focus:border-violet-400"/>
          <label className="mb-2 block text-sm font-medium">What are you promoting?</label><textarea value={topic} onChange={e=>setTopic(e.target.value)} placeholder="e.g. New arrivals, 10% off this weekend..." rows={4} className="mb-5 w-full resize-y rounded-xl border border-slate-700 bg-slate-950/70 px-4 py-3 outline-none focus:border-violet-400"/>
          <div className="grid gap-4 sm:grid-cols-2"><div><label className="mb-2 block text-sm font-medium">Platform</label><select value={platform} onChange={e=>setPlatform(e.target.value)} className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-3"><option>Instagram</option><option>Facebook</option><option>TikTok</option><option>WhatsApp</option><option>LinkedIn</option></select></div><div><label className="mb-2 block text-sm font-medium">Brand tone</label><select value={tone} onChange={e=>setTone(e.target.value)} className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-3"><option>Friendly</option><option>Professional</option><option>Playful</option><option>Luxury</option><option>Bold</option></select></div></div>
          <button onClick={generate} disabled={loading || !business.trim() || !topic.trim()} className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-violet-500 px-5 py-3 font-semibold hover:bg-violet-400 disabled:cursor-not-allowed disabled:opacity-50"><WandSparkles size={18}/>{loading ? 'Creating your post...' : 'Generate with AI'}</button>
          {error && <p className="mt-4 text-sm text-rose-300">{error}</p>}
        </section>
        <section className="panel min-h-[460px] p-6">
          <div className="flex items-center justify-between"><div><h2 className="font-bold">Your generated content</h2><p className="muted mt-1 text-xs">Your draft will appear here.</p></div>{result && <button onClick={copyContent} className="flex items-center gap-2 rounded-lg border border-slate-700 px-3 py-2 text-xs">{copied?<Check size={14}/>:<Copy size={14}/>} {copied?'Copied':'Copy'}</button>}</div>
          {!result && <div className="flex min-h-[350px] flex-col items-center justify-center text-center"><div className="rounded-2xl bg-slate-800/70 p-5 text-violet-300"><WandSparkles size={30}/></div><p className="mt-5 font-semibold">Ready when you are</p><p className="muted mt-2 max-w-xs text-sm leading-6">Fill in your business and promotion details, then generate your first draft.</p></div>}
          {result && <div className="mt-6"><div className="mb-3 inline-flex rounded-full bg-blue-400/10 px-3 py-1 text-xs text-blue-200">{platform} · {tone}</div><p className="whitespace-pre-wrap leading-7">{result.caption}</p><div className="mt-5 flex flex-wrap gap-2">{result.hashtags.map(tag=><span key={tag} className="rounded-full bg-violet-400/10 px-3 py-1 text-xs text-violet-200">{tag.startsWith('#')?tag:`#${tag}`}</span>)}</div><div className="mt-7 border-t border-slate-700 pt-5"><p className="mb-3 text-sm font-semibold">More content ideas</p><ul className="list-disc space-y-2 pl-5 text-sm muted">{result.ideas.map((idea,i)=><li key={i}>{idea}</li>)}</ul></div></div>}
        </section>
      </div>
      <p className="muted mt-8 text-xs">PostPilot AI is an early MVP. Review AI-generated content for accuracy before publishing.</p>
    </main>
  </div>;
}
