import Link from 'next/link';
import { ArrowRight, Sparkles, CalendarDays, ChartNoAxesCombined, WandSparkles } from 'lucide-react';

const features = [
  { icon: Sparkles, title: 'AI content studio', text: 'Turn a product, offer or idea into ready-to-use social content.' },
  { icon: CalendarDays, title: 'Plan your week', text: 'Organise campaign ideas and keep your posting consistent.' },
  { icon: ChartNoAxesCombined, title: 'Built for small teams', text: 'Keep brand voice and content ideas together in one workspace.' }
];

export default function Home() {
  return <main className="min-h-screen overflow-hidden">
    <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-6">
      <Link href="/" className="flex items-center gap-2 text-xl font-bold"><span className="rounded-xl bg-violet-500 p-2"><WandSparkles size={20}/></span>PostPilot<span className="gradient-text">AI</span></Link>
      <div className="flex items-center gap-3"><Link href="/login" className="text-sm muted hover:text-white">Sign in</Link><Link href="/signup" className="rounded-full border border-slate-700 px-5 py-2 text-sm hover:border-violet-400">Get started <ArrowRight className="ml-2 inline" size={15}/></Link></div>
    </nav>
    <section className="mx-auto grid max-w-7xl items-center gap-12 px-6 pb-24 pt-16 md:grid-cols-2 md:pt-24">
      <div>
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-violet-400/30 bg-violet-400/10 px-4 py-2 text-sm text-violet-200"><Sparkles size={15}/> Your AI marketing sidekick</div>
        <h1 className="max-w-2xl text-5xl font-black leading-tight md:text-7xl">Great content.<br/><span className="gradient-text">Less busywork.</span></h1>
        <p className="muted mt-6 max-w-xl text-lg leading-8">Create social captions, hashtags and campaign ideas for your business in seconds. Spend less time staring at a blank page and more time serving customers.</p>
        <div className="mt-9 flex flex-wrap gap-3"><Link href="/signup" className="rounded-xl bg-violet-500 px-6 py-3 font-semibold shadow-lg shadow-violet-950/40 hover:bg-violet-400">Try the content studio <ArrowRight className="ml-2 inline" size={17}/></Link><a href="#features" className="rounded-xl border border-slate-700 px-6 py-3 font-semibold hover:border-slate-500">Explore features</a></div>
        <p className="muted mt-4 text-xs">MVP preview · AI generation requires an API key</p>
      </div>
      <div className="panel relative p-5 shadow-2xl shadow-violet-950/30">
        <div className="mb-5 flex items-center justify-between"><div><p className="text-sm font-semibold">Content studio</p><p className="muted text-xs">Your next campaign starts here</p></div><span className="rounded-full bg-emerald-400/10 px-3 py-1 text-xs text-emerald-300">Ready</span></div>
        <div className="rounded-xl border border-slate-700 bg-slate-950/70 p-4"><p className="muted text-xs">CAMPAIGN IDEA</p><p className="mt-2 text-lg font-bold">Weekend offer for your store</p><div className="mt-4 h-2 w-full rounded bg-slate-800"><div className="h-2 w-4/5 rounded bg-gradient-to-r from-violet-500 to-blue-400"/></div><p className="muted mt-2 text-xs">Draft your message, choose a platform, generate.</p></div>
        <div className="mt-4 grid grid-cols-2 gap-3"><div className="rounded-xl bg-violet-500/10 p-4"><p className="muted text-xs">CAPTIONS</p><p className="mt-1 text-2xl font-bold">AI</p></div><div className="rounded-xl bg-blue-500/10 p-4"><p className="muted text-xs">HASHTAGS</p><p className="mt-1 text-2xl font-bold">Ready</p></div></div>
      </div>
    </section>
    <section id="features" className="mx-auto max-w-7xl px-6 pb-24"><p className="mb-3 text-sm font-semibold uppercase tracking-widest text-violet-300">Made for momentum</p><h2 className="text-3xl font-bold">Everything you need to get started</h2><div className="mt-8 grid gap-4 md:grid-cols-3">{features.map(({icon: Icon,title,text})=><div className="panel p-6" key={title}><Icon className="text-violet-300" size={25}/><h3 className="mt-5 text-lg font-bold">{title}</h3><p className="muted mt-2 leading-7">{text}</p></div>)}</div></section>
    <footer className="border-t border-slate-800 px-6 py-8 text-center text-sm muted">© {new Date().getFullYear()} PostPilot AI. Built for better business content.</footer>
  </main>;
}
