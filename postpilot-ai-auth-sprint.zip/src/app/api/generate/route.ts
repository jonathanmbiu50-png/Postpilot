import OpenAI from 'openai';
import { getSessionUser } from '@/lib/auth';
import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

export async function POST(request: Request) {
  try {
    const sessionUser = await getSessionUser();
    if (!sessionUser) return NextResponse.json({ error: 'Please sign in to generate content.' }, { status: 401 });
    const body = await request.json();
    const business = String(body.business || '').trim().slice(0, 120);
    const topic = String(body.topic || '').trim().slice(0, 1000);
    const platform = String(body.platform || 'Instagram').slice(0, 40);
    const tone = String(body.tone || 'Friendly').slice(0, 40);

    if (!business || !topic) {
      return NextResponse.json({ error: 'Add your business and what you want to promote.' }, { status: 400 });
    }
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: 'AI is not connected yet. Add OPENAI_API_KEY to your environment variables, then restart the app.' }, { status: 503 });
    }

    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const completion = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
      temperature: 0.8,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: 'You are a careful social media marketing assistant for small businesses. Return valid JSON with exactly these keys: caption (string), hashtags (array of 5 to 8 short strings, each starting with #), ideas (array of 3 short post ideas). Do not invent prices, discounts, guarantees, or product claims not provided by the user. Keep content useful, natural, and suitable for the selected platform.' },
        { role: 'user', content: `Business: ${business}\nPlatform: ${platform}\nTone: ${tone}\nPromotion/topic: ${topic}\nWrite one ready-to-edit post and three related ideas.` }
      ]
    });
    const raw = completion.choices[0]?.message?.content || '{}';
    const parsed = JSON.parse(raw);
    if (typeof parsed.caption !== 'string' || !Array.isArray(parsed.hashtags) || !Array.isArray(parsed.ideas)) {
      throw new Error('The AI returned an unexpected format. Please try again.');
    }
    return NextResponse.json({
      caption: parsed.caption,
      hashtags: parsed.hashtags.slice(0, 10).map(String),
      ideas: parsed.ideas.slice(0, 3).map(String)
    });
  } catch (error) {
    console.error('Content generation failed:', error);
    return NextResponse.json({ error: 'Content generation failed. Please check your setup and try again.' }, { status: 500 });
  }
}
