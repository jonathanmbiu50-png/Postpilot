# PostPilot AI

A standalone AI social-media content SaaS starter built with Next.js, TypeScript, Tailwind CSS, OpenAI and PostgreSQL/Prisma.

## Included in this MVP

- Marketing landing page
- Email/password registration and login with bcrypt password hashing
- Signed, HTTP-only, SameSite=Lax session cookies and protected dashboard/API
- Responsive content-studio dashboard
- AI caption, hashtag and content-idea generation
- Platform and brand-tone choices
- Copy generated content
- PostgreSQL Prisma schema for future user, brand and content persistence

## Run locally

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Add your OpenAI API key to `OPENAI_API_KEY`.
4. Add a PostgreSQL connection string to `DATABASE_URL`.
5. Set `AUTH_SECRET` to a cryptographically random secret of at least 32 characters.
6. Install and start:

```bash
npm install
npx prisma generate
npx prisma db push
npm run dev
```

Open http://localhost:3000.

AI generation will not work until a valid API key is configured. Keep API keys on the server; never put them in browser code or commit `.env`.

## Deploying on Render

1. Push this project to a GitHub repository.
2. In Render, create a PostgreSQL database.
3. Create a **Web Service** from the GitHub repository.
4. Build command: `npm install && npx prisma generate && npm run build`
5. Start command: `npm start`
6. Add environment variables:
   - `DATABASE_URL`: Render PostgreSQL **internal** connection string
   - `OPENAI_API_KEY`: your server-side API key
   - `OPENAI_MODEL`: `gpt-4o-mini`
7. Deploy and test `/` and `/dashboard`.

For a production launch, add database-backed rate limiting, password reset and email verification, CSRF/origin checks for all state-changing endpoints, per-user content persistence and quotas, billing/webhooks, privacy/terms pages, monitoring, automated backups and tested database migrations before accepting customers. The current session is a signed seven-day JWT cookie; add session revocation/rotation and account recovery before production.

## Important MVP limitations

This starter is a working UI and AI-generation foundation, not a finished paid SaaS. Authentication, saved content, subscriptions/payments, admin tools, automated publishing and a production content calendar are not implemented yet. The Prisma schema is a starting point for those features. Do not advertise features as live until implemented and tested.
