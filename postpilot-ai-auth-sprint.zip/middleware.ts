import { NextRequest, NextResponse } from 'next/server';
import { jwtVerify } from 'jose';

export async function middleware(request: NextRequest) {
  const token = request.cookies.get('postpilot_session')?.value;
  const secret = process.env.AUTH_SECRET;

  if (!token || !secret || secret.length < 32) {
    return NextResponse.redirect(new URL('/login', request.url));
  }

  try {
    await jwtVerify(token, new TextEncoder().encode(secret), { algorithms: ['HS256'] });
    return NextResponse.next();
  } catch {
    const response = NextResponse.redirect(new URL('/login', request.url));
    response.cookies.delete('postpilot_session');
    return response;
  }
}

export const config = {
  matcher: ['/dashboard/:path*']
};
